from twilio.rest import Client
import os
from dotenv import load_dotenv

load_dotenv()

account_sid = os.getenv("TWILIO_ACCOUNT_SID")
auth_token = os.getenv("TWILIO_AUTH_TOKEN")
twilio_number = os.getenv("TWILIO_PHONE_NUMBER")

client = Client(account_sid, auth_token)


def make_call(to_phone: str):
    call = client.calls.create(
        to=to_phone,
        from_=twilio_number,
        # This URL will return TwiML that tells Twilio to stream audio to your WebSocket
        url="https://1c04-49-36-81-71.ngrok-free.app/twilio/voice",
    )
    print(f"Outbound call initiated, Call SID: {call.sid}")


if __name__ == "__main__":
    make_call("+919427159397")
