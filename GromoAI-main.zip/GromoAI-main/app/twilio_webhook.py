from fastapi import APIRouter, Request, Response
from twilio.twiml.voice_response import VoiceResponse, Start

router = APIRouter()


@router.post("/twilio/voice")
async def twilio_voice_webhook(request: Request):
    form_data = await request.form()
    call_sid = form_data.get("CallSid", "unknown")

    response = VoiceResponse()

    start = Start()
    stream_url = f"wss://1c04-49-36-81-71.ngrok-free.app/ws/audio-stream/{call_sid}"
    start.stream(url=stream_url, track="inbound_track,outbound_track")
    response.append(start)

    response.say(
        "Disclaimer: This call may be recorded for quality and training purposes. "
        "Welcome to Gromo services. How can I help you today?",
        voice="Polly.Joanna",
    )

    return Response(content=str(response), media_type="application/xml")
