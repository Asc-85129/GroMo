import asyncio
import base64
import json
import os
import websockets
from dotenv import load_dotenv

load_dotenv()

ASSEMBLYAI_API_KEY = os.getenv("ASSEMBLYAI_API_KEY")
ASSEMBLYAI_REALTIME_URL = "wss://api.assemblyai.com/v2/realtime/ws?sample_rate=8000"

class Transcriber:
    def __init__(self, call_sid: str):
        self.call_sid = call_sid
        self.ws = None
        self.listen_task = None
        self.buffer = asyncio.Queue()

    async def connect(self):
        print(f"[{self.call_sid}]Connecting to AssemblyAI WebSocket")
        self.ws = await websockets.connect(
            ASSEMBLYAI_REALTIME_URL,
            extra_headers={"Authorization": ASSEMBLYAI_API_KEY},
            ping_interval=5,
            ping_timeout=20,
        )
        print(f"[{self.call_sid}]Connected to AssemblyAI")

        # Start background listener for transcripts
        self.listen_task = asyncio.create_task(self.listen_for_transcripts())

        # Start audio sender coroutine
        asyncio.create_task(self.send_audio_from_buffer())

    async def send_audio(self, audio_bytes: bytes):
        await self.buffer.put(audio_bytes)

    async def send_audio_from_buffer(self):
        while True:
            audio = await self.buffer.get()
            try:
                await self.ws.send(
                    json.dumps({
                        "audio_data": base64.b64encode(audio).decode("utf-8")
                    })
                )
            except Exception as e:
                print(f"[{self.call_sid}]Error sending audio: {e}")
                break

    async def listen_for_transcripts(self):
        try:
            async for msg in self.ws:
                res = json.loads(msg)
                if res.get("text") and res.get("message_type") == "FinalTranscript":
                    print(f"[{self.call_sid}]Final Transcript: {res['text']}")
                elif res.get("text"):
                    print(f"[{self.call_sid}]Partial: {res['text']}")
        except websockets.exceptions.ConnectionClosed as e:
            print(f"[{self.call_sid}]AssemblyAI WebSocket closed: {e}")

    async def close(self):
        if self.ws:
            await self.ws.send(json.dumps({"terminate_session": True}))
            await self.ws.close()
            print(f"[{self.call_sid}]Closed AssemblyAI WebSocket")
        if self.listen_task:
            self.listen_task.cancel()
