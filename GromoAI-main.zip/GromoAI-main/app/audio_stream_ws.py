import base64
from fastapi import APIRouter, WebSocket
from app.transcriber import Transcriber
router = APIRouter()
active_transcribers = {}
@router.websocket("/ws/audio-stream/{call_sid}")
async def audio_stream_ws(websocket: WebSocket, call_sid: str):
    await websocket.accept()
    print(f"WebSocket connection accepted for call {call_sid}")
    transcriber = Transcriber(call_sid)
    await transcriber.connect()
    active_transcribers[call_sid] = transcriber
    try:
        while True:
            data = await websocket.receive_json()
            event = data.get("event")

            if event == "start":
                print(f" Streaming started for call {call_sid}")
            elif event == "media":
                audio_b64 = data["media"].get("payload")
                if audio_b64:
                    audio_bytes = base64.b64decode(audio_b64)
                    await transcriber.send_audio(audio_bytes)
            elif event == "stop":
                print(f"Streaming stopped for call {call_sid}")
                break

    except Exception as e:
        print(f"WebSocket closed for call {call_sid}: {e}")
    finally:
        await transcriber.close()
        await websocket.close()
        del active_transcribers[call_sid]
        print(f"WebSocket closed for call {call_sid}")
