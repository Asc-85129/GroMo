from fastapi import FastAPI, APIRouter, WebSocket, WebSocketDisconnect, Request, Body
from twilio.twiml.voice_response import VoiceResponse, Start
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Optional
from uuid import uuid4
from pydantic import BaseModel
from agno_workflow import GPSuggestions


# from audio_streaming.twilio_ws_handler import handle_twilio_audio_stream
# from transcription.assemblyai_stream import transcribe_stream
# from tts.elevenlabs_tts import generate_tts_audio 
# from injection.twilio_audio_inject import stream_audio_back
# from frontend_ui.pitch_display import retrieve_cached_pitch


from agno_workflow import GPSuggestions
router = APIRouter()
app = FastAPI(title="AI Sales Call Assistant")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=[""], allow_headers=[""]
)

@router.post("/twilio/voice")
async def twilio_voice_webhook(request: Request):
    form_data = await request.form()
    call_sid = form_data.get("CallSid", "unknown")

    response = VoiceResponse()

    start = Start()
    stream_url = f"wss://1c04-49-36-81-71.ngrok-free.app/ws/audio-stream/{call_sid}"
    start.stream(url=stream_url, track="inbound_track,outbound_track")
    response.append(start)

    response.say(
        "Disclaimer: This call may be recorded for quality and training purposes. "
        "Welcome to Gromo services. How can I help you today?",
        voice="Polly.Joanna",
    )

    return Response(content=str(response), media_type="application/xml")


@router.websocket("/ws/audio-stream/{call_sid}")
async def audio_stream_ws(websocket: WebSocket, call_sid: str):
    await websocket.accept()
    print(f"WebSocket connection accepted for call {call_sid}")
    transcriber = Transcriber(call_sid)
    await transcriber.connect()
    active_transcribers[call_sid] = transcriber
    try:
        while True:
            data = await websocket.receive_json()
            event = data.get("event")

            if event == "start":
                print(f" Streaming started for call {call_sid}")
            elif event == "media":
                audio_b64 = data["media"].get("payload")
                if audio_b64:
                    audio_bytes = base64.b64decode(audio_b64)
                    await transcriber.send_audio(audio_bytes)
            elif event == "stop":
                print(f"Streaming stopped for call {call_sid}")
                break

    except Exception as e:
        print(f"WebSocket closed for call {call_sid}: {e}")
    finally:
        await transcriber.close()
        await websocket.close()
        del active_transcribers[call_sid]
        print(f"WebSocket closed for call {call_sid}")

class GPTInput(BaseModel):
    text: str
    user_id: str
 

@app.post("/agno/generate-pitch")
async def generate_pitch(data: GPTInput):
    pitch = GPSuggestions().run(data.text, user_id=data.user_id)
    return {"pitch": pitch}

class TextInput(BaseModel):
    text: str
@app.post("/tts/synthesize")
async def synthesize_audio(data: TextInput):
    audio = generate_tts_audio(data.text)
    return Response(content=audio, media_type="audio/mpeg")


class InjectRequest(BaseModel):
    audio_text: str
    call_sid: str

@app.post("/inject/play")
async def inject_audio(data: InjectRequest):
    audio = generate_tts_audio(data.audio_text)
    stream_audio_back(data.call_sid, audio)  
    return {"status": "Injected", "call_sid": data.call_sid}

@app.get("/pitch-screen/{call_id}")
async def get_pitch_screen(call_id: str):
    pitch = retrieve_cached_pitch(call_id)
    return {"call_id": call_id, "pitch": pitch}

# from fastapi import FastAPI
# from app import twilio_webhook, audio_stream_ws

# app = FastAPI()


# @app.get("/")
# async def root():
#     return {"message": "FastAPI app is running!"}


# app.include_router(twilio_webhook.router)
# app.include_router(audio_stream_ws.router)
